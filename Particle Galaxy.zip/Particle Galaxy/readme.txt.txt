To start the program, simply double click on "Particle Galaxy Executable". 

When you want to exit the program, click on the "x" button located in the top right corner of the 
window.